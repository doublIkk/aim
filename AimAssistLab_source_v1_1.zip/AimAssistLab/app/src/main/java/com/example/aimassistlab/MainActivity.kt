package com.example.aimassistlab

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Switch
import android.graphics.Color
import android.view.Gravity
import android.content.Context
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(13, 18, 29))
        }

        root.addView(TextView(this).apply {
            text = "AIM ASSIST LAB"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Учебная симуляция • работает только внутри приложения"
            textSize = 12f
            setTextColor(Color.rgb(155, 170, 194))
            setPadding(0, dp(4), 0, dp(8))
        })

        val demo = AimDemoView(this)
        root.addView(demo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val aimSwitch = Switch(this).apply {
            text = "Автонаведение на голову"
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = true
            setPadding(0, dp(4), 0, dp(4))
            setOnCheckedChangeListener { _, checked -> demo.autoAim = checked }
        }
        root.addView(aimSwitch)

        val fireSwitch = Switch(this).apply {
            text = "Автовыстрел (симуляция)"
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = true
            setPadding(0, dp(4), 0, dp(4))
            setOnCheckedChangeListener { _, checked -> demo.autoFire = checked }
        }
        root.addView(fireSwitch)

        val assistLabel = TextView(this).apply {
            text = "Сила наведения: 45%"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, 0)
        }
        root.addView(assistLabel)

        val strength = SeekBar(this).apply {
            max = 100
            progress = 45
        }
        root.addView(strength)
        strength.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                assistLabel.text = "Сила наведения: $progress%"
                demo.strength = progress / 100f
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val radiusLabel = TextView(this).apply {
            text = "Радиус захвата: 150 px"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(2), 0, 0)
        }
        root.addView(radiusLabel)
        val radius = SeekBar(this).apply {
            max = 260
            progress = 150
        }
        root.addView(radius)
        radius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress.coerceAtLeast(20)
                radiusLabel.text = "Радиус захвата: $value px"
                demo.captureRadius = value.toFloat()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val reset = TextView(this).apply {
            text = "Сбросить прицел и статистику"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(39, 70, 112))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { demo.resetDemo() }
        }
        val resetParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        resetParams.topMargin = dp(6)
        root.addView(reset, resetParams)

        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

private class AimDemoView(context: Context) : View(context) {
    var strength = 0.45f
    var captureRadius = 150f
    var autoAim = true
    var autoFire = true

    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var reticleX = 0f
    private var reticleY = 0f
    private var started = false
    private var startedAt = System.currentTimeMillis()
    private var lastFrame = System.currentTimeMillis()
    private var lastShotAt = 0L
    private var shots = 0
    private var hits = 0
    private var lastError = 0f
    private var inHeadZone = false
    private var shotFlashUntil = 0L

    private fun dp(v: Float) = v * density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        if (!started) {
            reticleX = w * 0.5f
            reticleY = h * 0.58f
            started = true
        }

        canvas.drawColor(Color.rgb(18, 26, 41))

        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1f)
        p.color = Color.rgb(34, 48, 69)
        val step = dp(28f)
        var gx = 0f
        while (gx < w) { canvas.drawLine(gx, 0f, gx, h, p); gx += step }
        var gy = 0f
        while (gy < h) { canvas.drawLine(0f, gy, w, gy, p); gy += step }

        val t = (System.currentTimeMillis() - startedAt) / 1000f
        val bodyX = w * 0.5f + cos(t * 0.85f) * w * 0.25f
        val bodyY = h * 0.47f + sin(t * 1.2f) * h * 0.10f
        val headX = bodyX
        val headY = bodyY - dp(27f)

        val dx = headX - reticleX
        val dy = headY - reticleY
        val error = sqrt(dx * dx + dy * dy)
        lastError = error
        inHeadZone = error <= dp(13f)

        val now = System.currentTimeMillis()
        val dt = ((now - lastFrame).coerceAtMost(50L)) / 16.67f
        lastFrame = now

        if (autoAim && error <= captureRadius) {
            val factor = (0.025f + strength * 0.25f) * dt.coerceAtMost(3f)
            reticleX += dx * factor
            reticleY += dy * factor
        }

        // Simulated automatic shot, strictly within this training scene.
        if (autoFire && inHeadZone && now - lastShotAt >= 650L) {
            shots++
            hits++
            lastShotAt = now
            shotFlashUntil = now + 180L
        }

        // Capture radius.
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.5f)
        p.color = if (error <= captureRadius) Color.rgb(63, 220, 170) else Color.rgb(100, 132, 170)
        canvas.drawCircle(reticleX, reticleY, captureRadius, p)

        // Training dummy body.
        p.color = Color.rgb(255, 91, 112)
        p.strokeWidth = dp(2f)
        val bw = dp(28f)
        val bh = dp(43f)
        canvas.drawRoundRect(RectF(bodyX-bw, bodyY, bodyX+bw, bodyY+bh), dp(6f), dp(6f), p)
        canvas.drawLine(bodyX, bodyY+dp(8f), bodyX, bodyY+bh-dp(4f), p)

        // Head hit zone.
        p.color = if (inHeadZone) Color.rgb(63, 220, 170) else Color.rgb(255, 190, 92)
        p.strokeWidth = dp(2f)
        canvas.drawCircle(headX, headY, dp(13f), p)
        canvas.drawCircle(headX, headY, dp(4f), p)

        // Reticle.
        p.color = Color.WHITE
        p.strokeWidth = dp(2f)
        val cr = dp(10f)
        canvas.drawLine(reticleX-cr, reticleY, reticleX-dp(3f), reticleY, p)
        canvas.drawLine(reticleX+dp(3f), reticleY, reticleX+cr, reticleY, p)
        canvas.drawLine(reticleX, reticleY-cr, reticleX, reticleY-dp(3f), p)
        canvas.drawLine(reticleX, reticleY+dp(3f), reticleX, reticleY+cr, p)
        canvas.drawCircle(reticleX, reticleY, dp(2f), p)

        p.style = Paint.Style.FILL
        p.textSize = dp(12f)
        p.color = Color.WHITE
        canvas.drawText("TRAINING RANGE", dp(12f), dp(22f), p)
        p.color = if (error <= captureRadius) Color.rgb(63, 220, 170) else Color.rgb(255, 190, 92)
        canvas.drawText(if (autoAim && error <= captureRadius) "AIM: TRACKING" else "AIM: SEARCHING", dp(12f), dp(42f), p)
        p.color = if (now < shotFlashUntil) Color.rgb(63, 220, 170) else Color.rgb(205, 216, 232)
        canvas.drawText(if (now < shotFlashUntil) "SIMULATED HEADSHOT!" else "Выстрелы: $shots  •  Попадания: $hits", dp(12f), h - dp(38f), p)
        p.color = Color.rgb(205, 216, 232)
        canvas.drawText("Ошибка: ${error.toInt()} px  •  ${if (inHeadZone) "В зоне головы" else "Мимо зоны головы"}", dp(12f), h - dp(17f), p)

        postInvalidateDelayed(16)
    }

    fun resetDemo() {
        reticleX = width * 0.5f
        reticleY = height * 0.58f
        shots = 0
        hits = 0
        lastShotAt = 0L
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            reticleX = event.x.coerceIn(0f, width.toFloat())
            reticleY = event.y.coerceIn(0f, height.toFloat())
            invalidate()
            return true
        }
        return true
    }
}
